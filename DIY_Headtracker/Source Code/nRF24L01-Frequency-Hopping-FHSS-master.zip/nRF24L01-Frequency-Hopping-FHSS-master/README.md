# nRF24L01-Frequency Hopping (FHSS)

This is my algorithm to implement Frequency Hopping (FHSS) with nRF24L01 and Arduino.

The code is very simple but it implements many control and reliability features that make it particularly robust.
You will find all the details in the code comments

I hope you can find it useful for your projects.

