# ADS1115 Analog Digital Converter AVR Library

Simple library for use the ADS1115 ADC with an AVR µC.

## Usage

### Setup

	i2c_init();
	
### Functions

## References

This project is proudly and heavily based on the following libraries:

- http://homepage.hispeed.ch/peterfleury/doxygen/avr-gcc-libraries/group__pfleury__ic2master.html